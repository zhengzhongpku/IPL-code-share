include("data_generation.jl");
include("solver_two_stage_pogs.jl");
include("Initializer.jl");
include("solver_subgradient.jl");
include("solver_high_acc_pogs.jl");
include("solver_low_acc_dual.jl");
include("solver_low_acc_pogs.jl");
include("solver_high_acc_dual.jl");
path_parent="./result/"
using CPUTime
low_max_iter_limit=2;
high_max_iter_limit=4;
function generated_pipeline(decoded::Int64)
    path_number=round(Int64,1e6+mod(decoded,round(Int64,1e6)));
    if ~isdir(path_parent*string(path_number)*"/")
        mkdir(path_parent*string(path_number)*"/");
    end

    decoded=round(Int64,mod(decoded,round(Int64,1e8))+1e8);
    path_target=path_parent*string(path_number)*"/"*"generated_data_" * string(decoded) * ".txt";
    if isfile(path_target)
        f=open(path_target,"r");
        contents=read(f,String);
        close(f);
        if occursin("Everything is completed for current trial.",contents)
            return 0
        end
    end
    acc_convergence = 1e-7;
    io=open(path_target,"w");
    println(io, "decoded_value: ",decoded);
    #This integer is used for generating experiment setting
    seed=1234;
    max_iter_universe=100;
    rho_coeff_sel=0.24;
    #个位：fail_multi,0 or 1
    fail_multi=convert(Float64, mod(decoded,10));
    if (fail_multi>1)
        error("fail multi");
    end
    ################################################
    #十位百位：0-12
    pfail=0.025*fld(mod(decoded,1000),10);
    if (pfail>0.30001)
        error("pfail");
    end
    #################################################
    #千位：0,1,2
    dd=500+1000*fld(mod(decoded,10000),1000);
    if (dd>2500.0001)
        error("dd");
    end
    #万位十万位0-12
    kk=2+0.25*fld(mod(decoded,round(Int64,1e6)),round(Int64,1e4));
    if (kk>8.0001)
        error("kk");
    end
    nn=round(Int64,kk*dd);
    #百万位千万位0-49
    num_n_vals=1+fld(mod(decoded,round(Int64,1e8)),round(Int64,1e6));
    if (num_n_vals>50.0001)
        error("num_n_vals");
    end
    ###########################################################################
    ########################Step One: generate dataset and the initializer################
    println(io,"fail_multi: ",fail_multi);
    println(io,"pfail: ",pfail);
    println(io,"dd: ",dd);
    println(io,"nn: ",nn);
    println(io,"num_n_vals: ",num_n_vals);
    
    (A,b,x)=data_generation(nn, dd, pfail, fail_multi, num_n_vals, seed);
    optimized_loss=norm((A*x).^2-b,1)/nn;
    println(io,"Optimized_loss: ",optimized_loss);
    
    (x_est_dir, magnitude_est) = NoisyOrthPromotingInit(A, b, 0.5, false);
    x_init = x_est_dir[:] * magnitude_est;

    ######################Step zero: local initialization#######################################
    CPUtic();
    x_init0 = copy(x);
    x_init0 .= x_init0 .+ 0.01;
    (x_est, objs, num_steps, outer_iters) = ProxLinearQuadratic_dual_low_acc(A / sqrt(nn), b / nn,
        x_init = x_init0, loss_tol=optimized_loss, maxiter=10, rho_coeff=rho_coeff_sel, loss_opt = optimized_loss);
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "Low accuracy dual Convergence local Completed");
    println(io, "Low accuracy dual Convergence local Final loss ", objs[end]);
    println(io, "Low accuracy dual Convergence local Loss Gap ", objs[end]-optimized_loss);
    println(io, "Low accuracy dual Convergence local relative recovery error: ", recovery_val_temp);
    println(io, "Low accuracy dual Convergence local Time consumption ", time_taken);
    println(io, "Low accuracy dual Convergence local subproblem iterations ", num_steps);
    println(io, "Low accuracy dual Convergence local Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "Low accuracy dual Convergence local projection norm: ", norm(proj_part));
    println(io, "Low accuracy dual Convergence local orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")
    if objs[end] - optimized_loss < -(1e-4)
        println(io, "There is sufficient evidence that the sharpness condition does not hold.")
        println(io, "Everything is completed for current trial")
        close(io)
        return 0;
    end
    ##############################################################################################
    ########################Step Two: two stage algorithm################
    
    CPUtic();
    x_est = zeros(dd);
    num_steps = 0;
    #tol=1e-3,maxiter=20
    (x_est, objs, num_steps1, outer_iters1) =
      ProxLinearQuadratic(A / sqrt(nn), b / nn,
                              x_init = x_init, tol=1e-3,
                              eps_qp=1e-5,
                              maxiter = 20);
    println(io,"First Stage Outer iterations: ", outer_iters1);
    println(io,"First Stage subproblem iterations: ", num_steps1);
    (x_est, objs, num_steps2, outer_iters2) =
      ProxLinearQuadratic(A / sqrt(nn), b / nn,
                              x_init = x_est, tol=1e-3,
                              #previously this is eps_qp=1e-8
                              eps_qp=1e-8,
                              maxiter = 20);
    loss_thresh=objs[end];
    println(io,"Second Stage Outer iterations: ", outer_iters2);
    println(io,"Second Stage subproblem iterations: ", num_steps2);
    println(io,"Second stage final loss: ", loss_thresh);
    
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "Two Stage Completed");
    println(io, "Two Stage Final loss ", objs[end]);
    println(io, "Two Stage Loss Gap ", objs[end]-optimized_loss);
    println(io, "Two Stage relative recovery error: ", recovery_val_temp);
    println(io, "Two Stage Time consumption ", time_taken);
    println(io, "Two Stage subproblem iterations ", num_steps1 + num_steps2);
    println(io, "Two Stage Outer iterations: ", outer_iters1+ outer_iters2);
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "Two Stage projection norm: ", norm(proj_part));
    println(io, "Two Stage orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")
    ########################Step Three: subgradient algorithm################
    
    CPUtic();
    (x_est, objs, num_steps) =
       Solving_problem_subgradient(A / sqrt(nn), b / nn,
                                x_init = x_init, loss_tol = loss_thresh,
                                maxiter = 10000);

    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "Subgradient Algorithm Completed.");
    println(io, "Subgradient Algorithm Final loss ", objs[end]);
    println(io, "Subgradient Algorithm Loss Gap ", objs[end]-optimized_loss);
    println(io, "Subgradient Algorithm relative recovery error: ", recovery_val_temp);
    println(io, "Subgradient Algorithm Time consumption ", time_taken);
    println(io, "Subgradient Algorithm Total iterations ", num_steps)
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "Subgradient Algorithm projection norm: ", norm(proj_part));
    println(io, "Subgradient Algorithm orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")

    CPUtic();
    (x_est, objs, num_steps) =
       Solving_problem_subgradient(A / sqrt(nn), b / nn,
                                x_init = x_init, loss_tol = optimized_loss + acc_convergence,
                                maxiter = 10000);

    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "Subgradient Algorithm Convergence Completed.");
    println(io, "Subgradient Algorithm Convergence Final loss ", objs[end]);
    println(io, "Subgradient Algorithm Convergence Loss Gap ", objs[end]-optimized_loss);
    println(io, "Subgradient Algorithm Convergence relative recovery error: ", recovery_val_temp);
    println(io, "Subgradient Algorithm Convergence Time consumption ", time_taken);
    println(io, "Subgradient Algorithm Convergence Total iterations ", num_steps)
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "Subgradient Algorithm Convergence projection norm: ", norm(proj_part));
    println(io, "Subgradient Algorithm Convergence orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")
    #######################Step Four: Low accuracy pogs###############################
    
    CPUtic();
    (x_est, objs, num_steps, outer_iters) = ProxLinearQuadratic_low_acc_pogs(A / sqrt(nn), b / nn,
        x_init = x_init, loss_tol=loss_thresh,
        maxiter=max_iter_universe, rho_coeff=rho_coeff_sel);
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "Low accuracy POGS Completed.");
    println(io, "Low accuracy POGS Final loss ", objs[end]);
    println(io, "Low accuracy POGS Loss Gap ", objs[end]-optimized_loss);
    println(io, "Low accuracy POGS relative recovery error: ", recovery_val_temp);
    println(io, "Low accuracy POGS Time consumption ", time_taken);
    println(io, "Low accuracy POGS subproblem iterations ", num_steps);
    println(io, "Low accuracy POGS Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "Low accuracy POGS projection norm: ", norm(proj_part));
    println(io, "Low accuracy POGS orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")


    CPUtic();
    (x_est, objs, num_steps, outer_iters) = ProxLinearQuadratic_low_acc_pogs(A / sqrt(nn), b / nn,
        x_init = x_init, loss_tol=optimized_loss + acc_convergence,
        maxiter=max_iter_universe, rho_coeff=rho_coeff_sel);
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "Low accuracy POGS Convergence Completed.");
    println(io, "Low accuracy POGS Convergence Final loss ", objs[end]);
    println(io, "Low accuracy POGS Convergence Loss Gap ", objs[end]-optimized_loss);
    println(io, "Low accuracy POGS Convergence relative recovery error: ", recovery_val_temp);
    println(io, "Low accuracy POGS Convergence Time consumption ", time_taken);
    println(io, "Low accuracy POGS Convergence subproblem iterations ", num_steps);
    println(io, "Low accuracy POGS Convergence Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "Low accuracy POGS Convergence projection norm: ", norm(proj_part));
    println(io, "Low accuracy POGS Convergence orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")

    #######################Step Five: High accuracy pogs###############################
    
    CPUtic();
    (x_est, objs, num_steps, outer_iters) = ProxLinearQuadratic_high_acc_pogs(A / sqrt(nn), b / nn,
        x_init = x_init, loss_tol=loss_thresh,
        maxiter=max_iter_universe, rho_coeff=rho_coeff_sel);
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "High accuracy POGS Completed.");
    println(io, "High accuracy POGS Final loss ", objs[end]);
    println(io, "High accuracy POGS Loss Gap ", objs[end]-optimized_loss);
    println(io, "High accuracy POGS relative recovery error: ", recovery_val_temp);
    println(io, "High accuracy POGS Time consumption ", time_taken);
    println(io, "High accuracy POGS subproblem iterations ", num_steps);
    println(io, "High accuracy POGS Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "High accuracy POGS projection norm: ", norm(proj_part));
    println(io, "High accuracy POGS orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")

    CPUtic();
    (x_est, objs, num_steps, outer_iters) = ProxLinearQuadratic_high_acc_pogs(A / sqrt(nn), b / nn,
        x_init = x_init, loss_tol=optimized_loss + acc_convergence,
        maxiter=max_iter_universe, rho_coeff=rho_coeff_sel);
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "High accuracy POGS Convergence Completed.");
    println(io, "High accuracy POGS Convergence Final loss ", objs[end]);
    println(io, "High accuracy POGS Convergence Loss Gap ", objs[end]-optimized_loss);
    println(io, "High accuracy POGS Convergence relative recovery error: ", recovery_val_temp);
    println(io, "High accuracy POGS Convergence Time consumption ", time_taken);
    println(io, "High accuracy POGS Convergence subproblem iterations ", num_steps);
    println(io, "High accuracy POGS Convergence Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "High accuracy POGS Convergence projection norm: ", norm(proj_part));
    println(io, "High accuracy POGS Convergence orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")

    #######################Step Six: Low accuracy dual###############################
    
    CPUtic();
    (x_est, objs, num_steps, outer_iters) = ProxLinearQuadratic_dual_low_acc(A / sqrt(nn), b / nn,
        x_init = x_init, loss_tol=loss_thresh,
        maxiter=max_iter_universe, rho_coeff=rho_coeff_sel);
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "Low accuracy dual Completed.");
    println(io, "Low accuracy dual Final loss ", objs[end]);
    println(io, "Low accuracy dual Loss Gap ", objs[end]-optimized_loss);
    println(io, "Low accuracy dual relative recovery error: ", recovery_val_temp);
    println(io, "Low accuracy dual Time consumption ", time_taken);
    println(io, "Low accuracy dual subproblem iterations ", num_steps);
    println(io, "Low accuracy dual Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "Low accuracy dual projection norm: ", norm(proj_part));
    println(io, "Low accuracy dual orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")
    #######################Step Six: Low accuracy dual convergence###############################
    CPUtic();
    (x_est, objs, num_steps, outer_iters) = ProxLinearQuadratic_dual_low_acc(A / sqrt(nn), b / nn,
        x_init = x_init, loss_tol=optimized_loss+acc_convergence,
        maxiter=max_iter_universe, rho_coeff=rho_coeff_sel);
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "Low accuracy dual Convergence Completed.");
    println(io, "Low accuracy dual Convergence Final loss ", objs[end]);
    println(io, "Low accuracy dual Convergence Loss Gap ", objs[end]-optimized_loss);
    println(io, "Low accuracy dual Convergence relative recovery error: ", recovery_val_temp);
    println(io, "Low accuracy dual Convergence Time consumption ", time_taken);
    println(io, "Low accuracy dual Convergence subproblem iterations ", num_steps);
    println(io, "Low accuracy dual Convergence Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "Low accuracy dual Convergence projection norm: ", norm(proj_part));
    println(io, "Low accuracy dual Convergence orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")
    #######################Step Seven: High accuracy dual###############################
    
    CPUtic();
    (x_est, objs, num_steps, outer_iters) = ProxLinearQuadratic_dual_high_acc(A / sqrt(nn), b / nn,
        x_init = x_init, loss_tol=loss_thresh,
        maxiter=max_iter_universe, rho_coeff=rho_coeff_sel);
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "High accuracy dual Completed.");
    println(io, "High accuracy dual Final loss ", objs[end]);
    println(io, "High accuracy dual Loss Gap ", objs[end]-optimized_loss);
    println(io, "High accuracy dual relative recovery error: ", recovery_val_temp);
    println(io, "High accuracy dual Time consumption ", time_taken);
    println(io, "High accuracy dual subproblem iterations ", num_steps);
    println(io, "High accuracy dual Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "High accuracy dual projection norm: ", norm(proj_part));
    println(io, "High accuracy dual orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")

    CPUtic();
    (x_est, objs, num_steps, outer_iters) = ProxLinearQuadratic_dual_high_acc(A / sqrt(nn), b / nn,
        x_init = x_init, loss_tol=optimized_loss + acc_convergence,
        maxiter=max_iter_universe, rho_coeff=rho_coeff_sel);
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "High accuracy dual Convergence Completed.");
    println(io, "High accuracy dual Convergence Final loss ", objs[end]);
    println(io, "High accuracy dual Convergence Loss Gap ", objs[end]-optimized_loss);
    println(io, "High accuracy dual Convergence relative recovery error: ", recovery_val_temp);
    println(io, "High accuracy dual Convergence Time consumption ", time_taken);
    println(io, "High accuracy dual Convergence subproblem iterations ", num_steps);
    println(io, "High accuracy dual Convergence Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "High accuracy dual Convergence projection norm: ", norm(proj_part));
    println(io, "High accuracy dual Convergence orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")
    println(io, "Everything is completed for current trial.")
    close(io);
end
# arg = parse(Int64, ARGS[1]);
# result=generated_pipeline(arg);
#include("pipeline.jl")
#03041021

#generated_pipeline(2121011);
