function ProxLinearQuadratic_dual_low_acc(A::Matrix{Float64}, b::Vector{Float64};
    x_init::Vector{Float64} = randn(size(A, 2)),
    update_tol::Float64 = -1.0,
    loss_tol::Float64 = 0.0,
    maxiter::Int64 = length(b),
    rho_coeff::Float64 = 0.5,
    loss_opt::Float64 = 0.0)
    
    x_curr = copy(x_init);
    (nn, dd) = size(A);
    opnorm_A = opnorm(A);
    lipschitz_const = 2 * opnorm_A^2;
    iter = 0;
    total_iters = 0;
    objs = [];
    iter_count=0;
    obj=Inf;
    steplength=Inf;

    #stepsize=20/(opnorm(2/lipschitz_const * diagm(b) * A)^2);
    stepsize=20/(sqrt(median(b))/opnorm_A);
    lambda_init=zeros(nn);
    subiter_limit_count=0;
    while ((iter < maxiter) && (obj>loss_tol) && (steplength > update_tol))
        dx = zeros(dd);
        inner_grad_mat = 2/lipschitz_const * diagm(A * x_curr) * A;

        (x_init, iter_count, lambda_init) =
        SolveQP_graph_form_dual_low_acc(inner_grad_mat, 1/lipschitz_const*(b - (A * x_curr).^2), 
            rho_coeff = rho_coeff, t_init=stepsize, lambda_init=lambda_init);
        total_iters += iter_count;

        x_curr .= x_curr .+ x_init;
        iter = iter + 1;
        if update_tol>0
            grad_map = lipschitz_const * x_init;
            steplength = norm(grad_map)
        end
        obj = sum(abs.((A * x_curr).^2 - b));
        objs = cat(objs, obj, dims=1);#some change happens here
        if iter_count>=1000-1
            subiter_limit_count = subiter_limit_count + 1;
        end
        if subiter_limit_count >= low_max_iter_limit
            break;
        end
    end
    return (x_curr, objs, total_iters, iter);
end
  
  
function SolveQP_graph_form_dual_low_acc(A::Matrix{Float64}, c_vec::Vector{Float64};
    MAXITER::Int64 = 1000,
    rho_coeff::Float64 = 0.5,
    t_init::Float64 = 1.0,
    lambda_init::Vector{Float64} = zeros(size(c_vec))[1])
#Lip_const=opnorm(A)^2;

    t=t_init;
    loss_init=norm(c_vec, 1);
    nn = length(c_vec);
    dd = size(A, 2);
    AT = zeros(dd,nn);
    AT .= A';
    iter = 0;
    lambda_x=zeros(nn);
    lambda_y=zeros(nn);
    lambda_x_record=zeros(nn);
    lambda_y_record=zeros(nn);
    lambda_z=zeros(nn);
    lambda_x .= lambda_init;
    lambda_y .= lambda_init;
    lambda_x_record .= lambda_init;
    lambda_y_record .= lambda_init;
    lambda_z .= lambda_init;
    x=zeros(dd);
    y=zeros(nn);
    c_minus_y=zeros(nn);
    temp1 = zeros(nn);
    temp2 = zeros(dd);

    gamma=1.0;
    loss_primal_part1=0.0;
    loss_primal_part2=0.0;
    loss_primal=loss_primal_part1+loss_primal_part2;
    loss_decrease=0.0;
    loss_gap=Inf;
    while (iter < MAXITER) && (loss_gap > rho_coeff*loss_decrease)
    lambda_z .= (1-gamma) .* lambda_x .+ gamma .* lambda_y;
    mul!(x, AT, lambda_z, -1, false)
    mul!(y,A,x);
    c_minus_y .= c_vec .- y;
    for counting in 0:100
        shrink=0.5^counting;
        lambda_y .= lambda_y_record .- (shrink*t/gamma) .* c_minus_y;
        lambda_y[lambda_y .> 1.0] .= 1.0;
        lambda_y[lambda_y .< -1.0] .= -1.0;
        lambda_x .= (1-gamma) .* lambda_x_record .+ gamma .* lambda_y;
        temp1 .= lambda_x .- lambda_z;
        mul!(temp2, AT, temp1);
        if (norm(temp2)^2 <= 1/shrink/t*norm(temp1)^2)
        lambda_x_record .= lambda_x;
        lambda_y_record .= lambda_y;
        t=t*shrink;
        break;
        end
    end
    gamma=2/(1+sqrt(1+4/(gamma^2)))
    loss_primal_part1=0.5*norm(x)^2;
    loss_primal_part2=norm(c_minus_y,1);
    loss_primal=loss_primal_part1+loss_primal_part2;
    loss_decrease=loss_init-loss_primal;
    loss_gap=2*loss_primal_part1+loss_primal_part2+dot(lambda_z,c_vec);
    iter += 1;
    end

    return (x, iter, lambda_y);
end