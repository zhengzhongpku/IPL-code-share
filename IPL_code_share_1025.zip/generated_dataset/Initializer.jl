using LinearAlgebra
using Arpack
using Statistics

function MinimizeOneDAbs(a::Vector{Float64}, b::Vector{Float64};
  tol::Float64 = 1e-8)
    nn = length(a);
    t_val = 0.0;
    max_t_val = norm(b, 1) / maximum(abs.(a));
    min_t_val = -max_t_val;
    nn = length(a);
    while (max_t_val - min_t_val > tol)
        t_val = (max_t_val + min_t_val) / 2;
        s = sum(sign.(a * t_val - b) .* a);
        if (s < 0)
            min_t_val = t_val;
        else
            max_t_val = t_val;
        end
    end
    return t_val;
end

function OrthogonalityPromotingInitialization(A::Matrix{Float64},
    b::Vector{Float64};
    prop_init::Float64 = .5,
    use_big::Bool = false)
    (nn, dd) = size(A);
    n_use = min(ceil(Int64, prop_init * nn), nn);
    A_norms = sqrt.(sum(A.^2, dims=2))[:];#add the parameter dims= here
    ###I change something here
    inds = sortperm(b ./ (A_norms.^2), lt = <);
    A_uniform = A .* repeat(1 ./A_norms, 1, dd);
    #put a space before ./ #change repmat to repeat
    S_small = A_uniform[inds[1:n_use], :]' * A_uniform[inds[1:n_use], :];
    S_big = (A_uniform[inds[(nn - n_use + 1):end], :]'
    * A_uniform[inds[(nn - n_use + 1):end], :]);
    S_small = Symmetric(S_small / n_use, :U);
    S_big = Symmetric(S_big / (nn - n_use + 1), :U);
    x_guess = zeros(dd);
    if (use_big)
        data = eigs(S_big, nev = 1, which=:LM);
        x_guess = data[2];
    else
    # Get smallest eigenvalue
        data = eigs(S_small, nev = 1, which=:SM);
        x_guess = data[2];
    end
    return x_guess[:];
end

function NoisyOrthPromotingInit(A::Matrix{Float64},
    b::Vector{Float64},
    prop_init::Float64 = .5,
    use_big::Bool = false)

    (nn, dd) = size(A);
    A_norms = sqrt.(sum(A.^2, dims=2))[:];
    A_uniform = A .* repeat(1 ./A_norms, 1, dd);
    x_guess = OrthogonalityPromotingInitialization(A, b, prop_init=prop_init,
                        use_big=use_big);
    t = MinimizeOneDAbs((A_uniform * x_guess).^2, b ./ (A_norms.^2));
    return (x_guess[:], sqrt(t));
end

