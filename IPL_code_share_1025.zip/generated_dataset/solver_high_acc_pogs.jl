function ProxLinearQuadratic_high_acc_pogs(A::Matrix{Float64}, b::Vector{Float64};
    x_init::Vector{Float64} = randn(size(A, 2)),
    loss_tol::Float64 = 0.0,
    update_tol::Float64 = -1.0,
    maxiter::Int64 = length(b),
    rho_coeff::Float64 = 0.5)
    #############################################
    x_curr = copy(x_init);
    (nn, dd) = size(A);
    lipschitz_const = 2 * opnorm(A)^2;
    iter = 0;
    total_iters = 0;
    objs = [];
    iter_count=0;
    obj=Inf;
    steplength=Inf;
    subiter_limit_count=0;
    while ((iter < maxiter) && (obj>loss_tol) && (steplength > update_tol))
    dx = zeros(dd);
    inner_grad_mat = 2/lipschitz_const * diagm(A * x_curr) * A;

    (x_init, iter_count) =SolveQP_graph_form_high_acc_pogs(inner_grad_mat, 1/lipschitz_const*(b - (A * x_curr).^2),
                rho = 4.0, rho_coeff = rho_coeff);
    total_iters += iter_count;
    x_curr .= x_curr .+ x_init;
    iter = iter + 1;
    if update_tol>0
    grad_map = lipschitz_const * x_init;
    steplength = norm(grad_map)
    end
    obj = sum(abs.((A * x_curr).^2 - b));
    objs = cat(objs, obj, dims=1);#some change happens here
    if iter_count>=1000-1
        subiter_limit_count=subiter_limit_count+1;
    end
    if subiter_limit_count >= high_max_iter_limit
        break;
    end
    end
    return (x_curr, objs, total_iters,iter);
end




function SolveQP_graph_form_high_acc_pogs(A::Matrix{Float64}, c_vec::Vector{Float64};
    rho::Float64 = 1.0,
    MAXITER::Int64 = 1000,
    rho_coeff::Float64 = 0.5)

    iter_condition_check=5;
    rho_inv=1/rho;
    nn = length(c_vec);
    dd = size(A, 2);
    AT = zeros(dd,nn);
    AT .= A';
    iter = 0;
    x_iter = zeros(dd);
    y_iter = zeros(nn);

    x_half = zeros(dd);
    y_half = zeros(nn);
    n_work_vec = zeros(nn);
    d_work_vec = zeros(dd);
    lambda = zeros(dd);
    nu = zeros(nn);
    nu_hard = zeros(nn);
    #IplusAtAinv = inv(eye(dd) + A' * A);
    IplusAtAinv = inv(I + A' * A); #Do some change here

    loss_init=norm(c_vec, 1);
    loss_primal=0.0;
    loss_dual=0.0;
    loss_decrease=0.0;
    loss_gap=Inf;
    rho_to_1_plus_pho=(rho / (1 + rho));
    ATy_half_plus_nu = zeros(dd);
    temp_quant = zeros(dd);
    norm_x_iter=0.0;
    while ((iter < MAXITER) && (loss_gap > rho_coeff/2*norm_x_iter^2))
        iter += 1;
        x_half .= rho_to_1_plus_pho .* (x_iter .- lambda);
        n_work_vec .= y_iter .- nu .- c_vec;

        y_half .= c_vec .+ sign.(n_work_vec) .* max.(abs.(n_work_vec) .- rho_inv, 0);
        #here is a modification that change - to .- for broadcasting

        mul!(ATy_half_plus_nu, AT, y_half + nu);
        d_work_vec .= x_half .+ lambda .+ ATy_half_plus_nu;
        mul!(x_iter, IplusAtAinv, d_work_vec);
        mul!(y_iter, A, x_iter);
        lambda .+= (x_half .- x_iter);
        nu .+= (y_half .- y_iter);
        if mod(iter, iter_condition_check)==0
            loss_primal = norm(x_iter)^2 / 2 + norm(y_iter - c_vec, 1);
            loss_decrease = loss_init-loss_primal;
            nu_hard .= nu;
            nu_hard[nu_hard .> rho_inv] .= rho_inv;
            nu_hard[nu_hard .< -rho_inv] .=-rho_inv;
            mul!(temp_quant, AT, nu_hard);
            loss_dual=rho*dot(c_vec,nu_hard)-rho^2/2*norm(
            temp_quant)^2-rho/2*norm(lambda+temp_quant)^2;
            loss_gap=loss_primal-loss_dual;
            norm_x_iter = norm(x_iter);
        else
            loss_gap = Inf;
        end
    end
    return (x_iter, iter);
end
  
  
