for failmulti in ["0","1"]
    for pfail in ["00","01","02","03","04","05","06","07","08","09","10","11","12"]
        for dd in ["0","1"]
            for kk in ["00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24"]
                path="./result/1"*kk*dd*pfail*failmulti*"/"
                if ~isdir(path)
                    mkdir(path);
                end
            end
        end
    end
end
