#!/bin/bash

#PBS -l nodes=1:ppn=1
#PBS -l walltime=48:00:00
#PBS -l pmem=4gb
#PBS -A open
#PBS -m n

cd /storage/work/z/zvz5337/IPL_gen_rerun_1210/
command_final="julia /storage/work/z/zvz5337/IPL_gen_rerun_1210/pipeline2_arr.jl ${command1}"
eval "${command_final}"
