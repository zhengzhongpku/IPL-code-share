This file provides a guidance on the Julia codes for generated dataset for IPL. We can replicate Figure 1 and Figure 2 with these codes. Part of the codes are from https://web.stanford.edu/~jduchi/projects/phase-retrieval-code.tgz

*****Part One: description of the code scripts.

pipeline_cpu.jl: main file that runs one experiment (out of 50 in total) of a given combination of dataset parameters (n, m/n, pfail, r). It will generate
datasets, run modified spectral initialization, run an test algorithm to terminate trials that sharpness assumption does not hold and run 6 candidate algorithms
(PL, subgradient, IPL with {low, high} \times {POGS, Fista}, for all the algorithms except PL, two tests are conducted. The one labeled with "convergence" represents using the threshold 1e-7 and the other uses the threshold based on PL). 
Here, the result of IPL with POGS is not reported in the paper. So, when doing replications, feel free to comment the corresponding codes.

solver_two_stage_pogs.jl: PL algorithm
solver_subgradient.jl: subgradient algorithm
solver_low_acc_pogs.jl: IPL-low-pogs
solver_high_acc_pogs.jl: IPL-high-pogs
solver_low_acc_dual.jl: IPL-low-fista
solver_high_acc_pogs.jl: IPL-high-fista
Initializer.jl: modified spectral initialization
data_generation.jl: generating the dataset

Other julia script and shell script files are for submitting jobs to linux servers.

***Part Two: One way to run the code and replicate the result.

First, uncomment the following two lines in 
# arg = parse(Int64, ARGS[1]);
# result=generated_pipeline(arg);

Next, in the terminal of a machine, under the trajectory of pipeline_cpu.jl, execute commands like 
julia pipeline_cpu.jl 102121011

Here 102121011 represents which experiment to run. We decode it as follows.
1, 02, 12, 1, 01, 1
The first part 1 is meaningless.
The second part represents the index of replication that takes 50 different values (00-49, must be two digits)
The third part represents m/n, which can takes 25 different values (00-24, must be two digits). Support that the value you provide is x, then m = (2+0.25*x)*n
The fourth part represents n that only takes two different values 0 and 1. 0 means n=500 and 1 means n=1500.
The fifth part represents the value of pfail that takes 13 different values (00-12, must be two digits).  Support that the value you provide is x, then pfail = 0.025*x
The sixth part represents the value of r (corruption type) that only takes two different values 0 and 1. Here 0 represents zeroing and 1 represents Cauchy as discussed in the paper.

You can change the number 102121011 to other ones to generate experiments for other settings.

After you finish executing the command, you can find an output txt file in the result folder (second level directory) using 102121011 as a part of the file name. You can collect the needed information there.