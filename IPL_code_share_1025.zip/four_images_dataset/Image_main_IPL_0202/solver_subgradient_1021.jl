function Solving_problem_subgradient(s_vec::Vector{Float64},
    b::Vector{Float64},
    x_init::Vector{Float64};
    loss_tol::Float64 = 1e-3,
    lambda::Float64 = -1.0,
    q::Float64 = 0.998,
    maxiter::Int64 = 10000,
    rel_tol::Float64=0.0,
    x_true = zeros(length(x_init)))

    dd=length(x_init);
    nn=length(s_vec);
    kk=round(Int64,nn/dd);
    x_curr = copy(x_init);
    if lambda<0
      lambda=norm(x_init)/10;
    end
    if (2^Hadamard.intlog(dd) != dd)
        error("Dimension must be power of 2.");
    end
    Wx = zeros(nn);
    dx = zeros(dd);
    d_work_vec = zeros(dd);
    n_work_vec = zeros(nn);
    obj = Inf;
    iter = 0;
    total_iters = 0;
    objs = [];
    #amplit=A * x_curr;
    MultiplyByDHS!(x_curr, s_vec, ones(nn), d_work_vec, Wx);
    res = Wx.^2 - b;
    stepsize=lambda/q;
    recovery_val_temp = Inf;
    while (iter < maxiter && obj > loss_tol && recovery_val_temp>rel_tol)
        stepsize=stepsize*q;
        #S' * H * diagm(D) * v
        MultiplyByDHST!(Wx .* sign.(res), s_vec, 2*ones(nn), n_work_vec, dx);
        #dx = 2 * (A') * (Wx .* sign.(res));
        dx = dx/norm(dx);
        x_curr = x_curr - stepsize*dx[:];
        iter = iter + 1;
        #amplit = A * x_curr;
        MultiplyByDHS!(x_curr, s_vec, ones(nn), d_work_vec, Wx);
        res = Wx.^2 - b;
        obj = sum(abs.(res));
        objs = cat(objs, obj, dims=1);#some change happens here
        recovery_val_temp = min(norm(x_curr - x_true) / norm(x_true), norm(x_curr + x_true) / norm(x_true));
        # if mod(iter,100)==0
        #   println(obj)
        # end
    end
    total_iters=iter;
    return (x_curr, objs, total_iters);
end
