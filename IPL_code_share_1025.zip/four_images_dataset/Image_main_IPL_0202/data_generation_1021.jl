function ConvertImageToFloats(path_image::String, dim::Int64)
    picture = imread(path_image);
    if (size(picture, 3) >= 3)
        picture = picture[:, :, 1:3];
    end
    kk = 3;
    N = prod(size(picture));
    stride_size = sqrt(N / dim);#If N>dim, the shape cannot holds so much pixels, there will be sampling
    if (stride_size < 1)
        stride_size = 1;
    end
    horiz_len = size(picture, 2);
    vert_len = size(picture, 1);
    h_inds = map((x) -> round(Int64, x),
                range(1, stop=horiz_len, length=floor(Int64,horiz_len / stride_size)));
    v_inds = map((x) -> round(Int64, x),
                range(1, stop=vert_len, length=floor(Int64,vert_len / stride_size)));
    sub_image = picture[v_inds, h_inds, :];#This argument can make sure that the sub-image won't have more pixels than dim
    len_sub_image = length(sub_image[:]);
    dim_sel=2^ceil(Int64, log2(len_sub_image));
    x_star = vcat(sub_image[:], zeros(dim_sel - len_sub_image));
    return x_star[:]
end
function data_generation_1021(
    path_image::String,
    log_dim::Int64 = 22,
    kk::Int64 = 3,
    p_fail::Float64 = 0.1,
    fail_multi::Float64 = 1.0,
    num_n_vals::Int64 = 16,#Before this generation, there are num_n_vals-1 generations in total
    seed::Int64 = 2017)
    ###############part one: load and convert the image######################
    Random.seed!(seed);
    x = ConvertImageToFloats(path_image, 2^log_dim);

    dd = length(x);
    nn = kk*dd;
    if 2^round(Int64, log2(dd))!=dd
        error("hadamard_not_suitable");
    end
    n_fail=round(Int64, nn * p_fail);
    work_vec = zeros(dd);
    s_vec = zeros(nn);
    obs_vec = zeros(nn);
    for i in range(1,stop=num_n_vals)
        s_vec .= sign.(randn(nn)) ./ sqrt(kk);
        MultiplyByHS!(x, s_vec, work_vec, obs_vec);
        obs_vec .= obs_vec.^2;
        if n_fail>0
            fail_inds = sample(1:nn, n_fail; replace=false);
            #median of corruption equals to the median of b_true
            corruptions=tan.((pi/2-1e-10)*rand(n_fail)) .* median(obs_vec) .* fail_multi;
            obs_vec[fail_inds] .= corruptions;
        end
    end
    return (obs_vec, s_vec, x)
end