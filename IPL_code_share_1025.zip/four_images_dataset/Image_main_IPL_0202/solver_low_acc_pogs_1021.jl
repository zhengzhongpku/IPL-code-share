#MAX_iter_global is defined in the main file
function ProxLinearQuadratic_low_acc_pogs(x_init::Vector{Float64},
        s_vec::Vector{Float64},
        b::Vector{Float64};
        maxiter::Int64=length(s_vec),
        loss_tol::Float64=0.0,
        update_tol::Float64=-1.0,
        rho_coeff::Float64=0.4,
        rel_tol::Float64=0.0,
        x_true = zeros(length(x_init)))
    x_curr = copy(x_init);
    dd = length(x_curr);# variable number
    nn = length(s_vec);# sample size
    kk = ceil(Int64, nn / dd);
    if (2^Hadamard.intlog(dd) != dd)
        error("Dimension must be power of 2.");
    end
    b_vec = copy(b);
    iter = 0;
    grad_map_norm = Inf;
    objs = zeros(maxiter);
    Wx = zeros(nn);
    grad_map=zeros(dd);
    
    x_delta = zeros(dd);
    d_work_vec = zeros(dd);
    total_cg_calcs = 0;
    lipschitz_const = 2;
    MultiplyByHS!(x_curr, s_vec, d_work_vec, Wx);
    c_vec =  b_vec .- (Wx).^2;
    D = 2 * Wx;
    subiter_count=0;
    obj = Inf;
    sub_limit_count=0;
    recovery_val_temp = Inf;
    while ((iter < maxiter) && (grad_map_norm > update_tol) && (obj > loss_tol) && (recovery_val_temp > rel_tol))
        (x_delta, cg_iters, subiters) = SolveQP_graph_form_low_acc_pogs(dd, s_vec, (1/lipschitz_const)*D , (1/lipschitz_const)*c_vec, 
                                                rho=rho_admm,rho_coeff=rho_coeff);
        total_cg_calcs += cg_iters;
        subiter_count += subiters;
        grad_map .= (lipschitz_const/2) .* x_delta;
        x_curr .= x_curr .+ x_delta;
        grad_map_norm=Inf;
        iter = iter + 1;
        MultiplyByHS!(x_curr, s_vec, d_work_vec, Wx);
        D .= 2 .* Wx;
        c_vec .= b_vec .- Wx.^2;
        obj = norm(c_vec, 1);
        objs[iter] = obj;
        #println("Iteration: ", iter,", loss: ", obj, ", subiter: ", subiters);
        recovery_val_temp = min(norm(x_curr - x_true) / norm(x_true), norm(x_curr + x_true) / norm(x_true));
        if subiters >= MAX_iter_global-1
            sub_limit_count=sub_limit_count+1;
        end
        if sub_limit_count>=maxiter_sub_limit1
            break;
        end
    end
    objs = objs[1:iter];
    
    return (x_curr, objs, total_cg_calcs, subiter_count, iter);
end

function SolveQP_graph_form_low_acc_pogs(dd::Int64, s_vec::Vector{Float64},
    D::Vector{Float64}, c_vec::Vector{Float64};
    rho::Float64=0.5,
    rho_coeff::Float64=0.5,
    MAXITER::Int64=MAX_iter_global)

    temp_quant=zeros(dd);
    rho_inv=1/rho;
    rho_gen_const=(rho / (1 + rho));
    nn = length(s_vec);
    kk = round(Int64, nn / dd);
    x_iter = zeros(dd);
    y_iter = zeros(nn);
    x_half = zeros(dd);
    y_half = zeros(nn);
    n_work_vec = zeros(nn);
    d_work_vec = zeros(dd);

    ATlambda = zeros(dd);  # Scratch vector for A' * stuff
    lambda = zeros(dd);
    nu = zeros(nn);
    nu_hard = zeros(nn);
    loss_init=norm(c_vec, 1);
    loss_primal=0.0;
    loss_dual=0.0;
    loss_decrease=0.0;
    loss_gap=Inf;
    total_cgs = 0;
    iter = 0;
    while ((iter < MAXITER) && (loss_gap > rho_coeff*loss_decrease))
        iter += 1;
# Compute update steps
# x_half = (rho / (1 + rho)) * (x_iter - lambda);
# n_work_vec = y_iter - nu - c_vec;
# y_half = (c_vec + sign(n_work_vec) .* max(abs(n_work_vec) - 1/rho, 0));
        @inbounds begin
            for jj = 1:dd
                x_half[jj] = rho_gen_const * (x_iter[jj] - lambda[jj]);
            end
            for jj = 1:nn
                n_work_vec[jj] = y_iter[jj] - nu[jj] - c_vec[jj];
                y_half[jj] = (c_vec[jj] + sign.(n_work_vec[jj]) .* max.(abs.(n_work_vec[jj]) - rho_inv, 0));
            end
        end

# TODO(jduchi): Could replace these inline additions to make
# things run faster if we did them with for-loops.
        MultiplyByDHST!(y_half + nu, s_vec, D, n_work_vec, ATlambda);
        (x_iter, num_cgs) =InvertHadamardSystem(dd, s_vec, 1.0, D.^2,
            ATlambda .+ x_half .+ lambda, x_init=x_iter);
        total_cgs += num_cgs;
        MultiplyByDHS!(x_iter, s_vec, D, d_work_vec, y_iter);

# NOTE: These @inbounds methods make everything run much faster.
# They avoid calling the "elementwise" and "collect" operations on
# vectors.
        @inbounds for jj = 1:dd
            lambda[jj] += (x_half[jj] - x_iter[jj]);
        end
        @inbounds for jj = 1:nn
            nu[jj] += (y_half[jj] - y_iter[jj]);
        end
        if mod(iter,5)==0
            loss_primal = norm(x_iter)^2 / 2 + norm(y_iter - c_vec, 1);
            loss_decrease = loss_init - loss_primal;
            nu_hard .= nu;
            nu_hard[nu_hard .> rho_inv] .= rho_inv;
            nu_hard[nu_hard .< -rho_inv] .=-rho_inv;
            #temp_quant=A'*nu_hard;
            MultiplyByDHST!(nu_hard, s_vec, D, n_work_vec, temp_quant)
    # MultiplyByDHST!(v, s, D, n_work_vec, result)
    #
    # Sets result = S' * H * diagm(D) * v, where H and S are defined as in
    # the header to this file. The vector n_work_vec is a size n vector,
    # where v is of size n as well. result is of size d.
            loss_dual=rho*dot(c_vec,nu)-rho^2/2*norm(
              temp_quant)^2-rho/2*norm(lambda+temp_quant)^2;
            loss_gap=loss_primal-loss_dual;
        else
            loss_gap=Inf;
        end
    end
    return (x_iter, total_cgs, iter);
end
