#!/bin/bash
declare -a arr1_collection=("0" "1")
declare -a arr2_collection=("0" "1" "2" "3" "4" "5" "6" "7" "8" "9")
for arr1 in "${arr1_collection[@]}"
do
   for arr2 in "${arr2_collection[@]}"
   do
      commanding="${arr1}${arr2}"
      qsub -v command1="${commanding}" generated_data_submission_arr.sh
   done
done
