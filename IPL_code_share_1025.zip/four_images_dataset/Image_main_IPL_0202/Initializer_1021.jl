function OrthogonalityInitializer(dd::Int64,
            s_vec::Vector{Float64},
            b::Vector{Float64};
            maxiter::Int64=50,
            p_val::Float64=.5,
            tol::Float64=1e-5,
            use_big::Bool=false)
    Random.seed!(10086);
    dir = randn(dd);
    dir .= dir ./ norm(dir);
    nn = length(s_vec);
    kk = round(Int64, nn / dd);
    b_quant = quantile(b, p_val);
    D = float(b .<= b_quant);
    if (use_big)
        D = float(b .> b_quant);
    end
    n_work_vec = zeros(nn);
    d_work_vec = zeros(dd);
    DAdir = zeros(nn);
    dir_change = zeros(dd);
    iter = 0;
    norm_change = Inf;
    while (iter < maxiter && norm_change > tol)
        iter += 1;
        dir_change[:] = dir;
        MultiplyByDHS!(dir, s_vec, D, d_work_vec, DAdir);
        MultiplyByDHST!(DAdir, s_vec, D, n_work_vec, d_work_vec);
        if (use_big)
            dir = d_work_vec;
        else
            dir = dir - d_work_vec;
        end
        dir = dir / norm(dir);
        dir_change -= dir;
        norm_change = norm(dir_change);
    end
# Now, solve simple median-like problem to find magnitude of the direction.
    MultiplyByDHS!(dir, s_vec, ones(nn), d_work_vec, n_work_vec);
    n_work_vec = n_work_vec.^2;
# (see file robust-quadatics.jl)
    t_val = MinimizeOneDAbs(n_work_vec, b .* (b .>= 0));
    return dir[:] * sqrt(t_val);
end

function MinimizeOneDAbs(a::Vector{Float64}, b::Vector{Float64};
tol::Float64=1e-8)
    nn = length(a);
    t_val = 0.0;
    max_t_val = norm(b, 1) / maximum(abs.(a));
    min_t_val = -max_t_val;
    nn = length(a);
    while (max_t_val - min_t_val > tol)
        t_val = (max_t_val + min_t_val) / 2;
        s = sum(sign.(a * t_val - b) .* a);
        if (s < 0)
            min_t_val = t_val;
        else
            max_t_val = t_val;
        end
    end
    return t_val;
end