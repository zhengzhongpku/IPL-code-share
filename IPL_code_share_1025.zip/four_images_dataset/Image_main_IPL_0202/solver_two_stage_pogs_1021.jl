
function ProxLinearQuadratic(x_init::Vector{Float64},
  s_vec::Vector{Float64},
  b::Vector{Float64};
  maxiter::Int64=length(s_vec),
  tol::Float64=1e-3,
  eps_qp::Float64=1e-4,
  rel_tol::Float64=0.0,
  x_true = zeros(length(x_init)))
    x_curr = copy(x_init);
    dd = length(x_curr);# variable number
    nn = length(s_vec);# sample size
    kk = ceil(Int64, nn / dd);
    R_vec = zeros(nn);
    measure_inds = 1:length(s_vec);
    R_vec[measure_inds] .= 1;
    b_vec = copy(b);
    iter = 0;
    grad_map_norm = Inf;
    objs = zeros(maxiter);
    Wx = zeros(nn);
    x_delta = zeros(dd);
    d_work_vec = zeros(dd);
    total_cg_calcs = 0;
    lipschitz_const = 2;
    MultiplyByDHS!(x_curr, s_vec, R_vec, d_work_vec, Wx);
    obj = norm((Wx).^2 - b_vec, 1);
    subiter_count=0;
    while (iter < maxiter && grad_map_norm > tol)
# First, compute objective
# obj = norm((A * x).^2 - b)
# Now, time to compute derivative matrices, etc.
        D = 2 * Wx;
        c_vec = b_vec - Wx.^2;
        # Set x_delta to minimize
        # norm(diagm(D) H * S * x - c_vec, 1) + norm(x)^2
        (x_delta, cg_iters, subiters) = SolveQP_graph_form(dd, s_vec, (1/lipschitz_const)*D , (1/lipschitz_const)*c_vec,
                rho=rho_admm,
                eps_abs=eps_qp,
                eps_rel=eps_qp);
        total_cg_calcs += cg_iters;
        subiter_count += subiters;
        grad_map = lipschitz_const/2 * x_delta;
        x_curr = x_curr + x_delta;
        grad_map_norm = norm(grad_map);
        iter = iter + 1;
        MultiplyByDHS!(x_curr, s_vec, R_vec, d_work_vec, Wx);
        obj = norm((Wx).^2 - b_vec, 1);
        objs[iter] = obj;
        #println("Iteration: ", iter,", loss: ", obj, ", subiter: ", subiters);
    end
    objs = objs[1:iter];
    return (x_curr, objs, total_cg_calcs, subiter_count, iter);
end
# min. norm(A * x - c, 1) + (1/2) * norm(x)^2
function SolveQP_graph_form(dd::Int64, s_vec::Vector{Float64},
    D::Vector{Float64}, c_vec::Vector{Float64};
    eps_abs::Float64=1e-5,
    rho::Float64=0.5,
    eps_rel::Float64=1e-4,
    MAXITER::Int64=MAX_iter_global)

    primal_residual_norm = Inf;
    dual_residual_norm = Inf;
    norm_duals = 0.0;
    norm_primals = 0.0;
    nn = length(s_vec);
    kk = round(Int64, nn / dd);
    x_iter = zeros(dd);
    y_iter = zeros(nn);
    x_half = zeros(dd);
    y_half = zeros(nn);
    n_work_vec = zeros(nn);
    d_work_vec = zeros(dd);
    resid_dual = zeros(dd + nn);
    resid_primal = zeros(dd + nn);
    Ax = zeros(nn);  # A * x
    ATlambda = zeros(dd);  # Scratch vector for A' * stuff
    lambda = zeros(dd);
    nu = zeros(nn);
    obj = Inf;
    total_cgs = 0;
    iter = 0;
    while (((primal_residual_norm > sqrt(nn+dd) * eps_abs + eps_rel * norm_primals) ||
        (dual_residual_norm > sqrt(nn+dd) * eps_abs + eps_rel * norm_duals)) && iter < MAXITER)

        iter += 1;
# Store residuals for later use
        resid_dual[1:dd] = x_iter;
        resid_dual[(dd + 1):end] = y_iter;
# Compute update steps
# x_half = (rho / (1 + rho)) * (x_iter - lambda);
# n_work_vec = y_iter - nu - c_vec;
# y_half = (c_vec + sign(n_work_vec) .* max(abs(n_work_vec) - 1/rho, 0));
        @inbounds begin
            for jj = 1:dd
                x_half[jj] = (rho / (1 + rho)) * (x_iter[jj] - lambda[jj]);
            end
            for jj = 1:nn
                n_work_vec[jj] = y_iter[jj] - nu[jj] - c_vec[jj];
                y_half[jj] = (c_vec[jj] + sign.(n_work_vec[jj]) .* max.(abs.(n_work_vec[jj]) - 1 / rho, 0));
            end
        end

# TODO(jduchi): Could replace these inline additions to make
# things run faster if we did them with for-loops.
        MultiplyByDHST!(y_half + nu, s_vec, D, n_work_vec, ATlambda);
        (x_iter, num_cgs) = InvertHadamardSystem(dd, s_vec, 1.0, D.^2,
            ATlambda + x_half + lambda, x_init=x_iter);
        total_cgs += num_cgs;
        MultiplyByDHS!(x_iter, s_vec, D, d_work_vec, y_iter);

# NOTE: These @inbounds methods make everything run much faster.
# They avoid calling the "elementwise" and "collect" operations on
# vectors.
        @inbounds for jj = 1:dd
            lambda[jj] += (x_half[jj] - x_iter[jj]);
        end
        @inbounds for jj = 1:nn
            nu[jj] += (y_half[jj] - y_iter[jj]);
        end

# Primal residual = [x_{k+1}; y_{k+1}] - [x_{k + 1/2}, y_{k + 1/2}]
# Dual residual = rho * [x_k - x_{k + 1}; y_k - y_{k + 1}].
        @inbounds for jj = 1:dd
            resid_primal[jj] = x_half[jj] - x_iter[jj];
            resid_dual[jj] -= x_iter[jj];
        end
        @inbounds for jj = 1:nn
            resid_primal[dd + jj] = y_half[jj] - y_iter[jj];
            resid_dual[dd + jj] -= y_iter[jj];
        end
        primal_residual_norm = norm(resid_primal);
        dual_residual_norm = rho * norm(resid_dual);
        norm_primals = max(sqrt(dot(x_iter, x_iter) + dot(y_iter, y_iter)),
            sqrt(dot(y_half, y_half) + dot(x_half, x_half)));
        norm_duals = rho * sqrt(dot(lambda, lambda) + dot(nu, nu));
        obj = dot(x_iter, x_iter) / 2 + norm(y_iter - c_vec, 1);
    end
    return (x_iter, total_cgs, iter);
end