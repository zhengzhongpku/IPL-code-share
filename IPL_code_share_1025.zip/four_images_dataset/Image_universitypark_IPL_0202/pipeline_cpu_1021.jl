MAX_iter_global=1000;
seed=1234;
max_iter_universe=50;
rho_coeff_sel_1=1.0;
rho_coeff_sel_2=0.24;
rho_admm=2.0;
maxiter_sub_limit1=2;
maxiter_sub_limit2=4;
include("utility_functions_1021.jl")
include("data_generation_1021.jl");
include("Initializer_1021.jl");
include("solver_two_stage_pogs_1021.jl");
include("solver_subgradient_1021.jl");
include("solver_high_acc_pogs_1021.jl");
include("solver_low_acc_dual_1021.jl");
include("solver_low_acc_pogs_1021.jl");
include("solver_high_acc_dual_1021.jl");
path_parent="./result/"
using CPUTime
function generated_pipeline(decoded::Int64)
    log_dim=22;
    path_number=round(Int64,1e3+mod(decoded,round(Int64,1e3)));
    if ~isdir(path_parent*string(path_number)*"/")
        mkdir(path_parent*string(path_number)*"/");
    end

    decoded=round(Int64,mod(decoded,round(Int64,1e5))+1e5);
    path_target=path_parent*string(path_number)*"/"*"rna_real_data_" * string(decoded) * ".txt";
    if isfile(path_target)
        f=open(path_target,"r");
        contents=read(f,String);
        close(f);
        if occursin("Everything is completed for current trial.",contents)
            return 0
        end
    end
    io=open(path_target,"w");
    println(io, "decoded_value: ",decoded);
    #This integer is used for generating experiment setting

    #个位：fail_multi,0 or 1
    fail_multi=convert(Float64, mod(decoded,10));
    if (fail_multi>1)
        error("fail multi");
    end
    ################################################
    #十位：0-8
    pfail=0.025*fld(mod(decoded,100),10);
    if (pfail>0.20001)
        error("pfail");
    end
    #################################################
    #百位0-1
    kk=3+3*fld(mod(decoded,round(Int64,1000)),round(Int64,100));
    if (kk>6.0001)
        error("kk");
    end
    
    #千位万位0-49
    num_n_vals=1+fld(mod(decoded,round(Int64,100000)),round(Int64,1000));
    if (num_n_vals>50.0001)
        error("num_n_vals");
    end
    ###########################################################################
    ########################Step One: generate dataset and the initializer################
    (b, s_vec, x)=data_generation_1021("./Data/Old-Main-Pennsylvania-State-University-Park-Pa.png", log_dim, kk, pfail, fail_multi, num_n_vals, seed);
    dd=length(x);
    nn=length(s_vec);
    println(io,"fail_multi: ",fail_multi);
    println(io,"pfail: ",pfail);
    println(io,"dd: ",dd);
    println(io,"nn: ",nn);
    println(io,"num_n_vals: ",num_n_vals);
    Wx=zeros(nn);
    work_vec = zeros(dd);
    MultiplyByHS!(x, s_vec, work_vec, Wx);
    optimized_loss=norm(Wx.^2-b,1);
    println(io,"Optimized_loss: ",optimized_loss);
    x_init = OrthogonalityInitializer(dd, s_vec, b, maxiter = 300, p_val = 0.75, use_big=false);
    ########################Step Two: two stage algorithm################
    # println("Initialization");
    # loss_thresh=0.0;



    # x_est = copy(x) .+ 0.0001;
    # CPUtic();
    # (x_est, objs, num_steps, outer_iters)=ProxLinearQuadratic_dual_low_acc(x_est, s_vec, b; 
    #             maxiter=10, loss_tol=optimized_loss, rho_coeff=rho_coeff_sel_1);
    # time_taken = CPUtoc();
    # recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    # println(io, "#################################################################################")
    # println(io, "Low accuracy dual Convergence local Completed");
    # println(io, "Low accuracy dual Convergence local Final loss ", objs[end]);
    # println(io, "Low accuracy dual Convergence local Loss Gap ", objs[end]-optimized_loss);
    # println(io, "Low accuracy dual Convergence local relative recovery error: ", recovery_val_temp);
    # println(io, "Low accuracy dual Convergence local Time consumption ", time_taken);
    # println(io, "Low accuracy dual Convergence local subproblem iterations ", num_steps);
    # println(io, "Low accuracy dual Convergence local Outer iterations: ", outer_iters);
    # proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    # orth_part=x_est-proj_part;
    # println(io, "Low accuracy dual Convergence local projection norm: ", norm(proj_part));
    # println(io, "Low accuracy dual Convergence local orthogonal norm: ", norm(orth_part));
    # println(io, "#################################################################################")
    # if objs[end] - optimized_loss < -(1e-4)
    #     println(io, "There is sufficient evidence that the sharpness condition does not hold.")
    #     println(io, "Everything is completed for current trial")
    #     close(io)
    #     return 0;
    # end
    # println(io, "Everything is completed for current trial")
    # CPUtic();
    # x_est = copy(x_init);
    # num_steps = 0;
    # #tol=1e-3,maxiter=20
    # (x_est, objs, total_cg_calcs1, num_steps1, outer_iters1) = ProxLinearQuadratic(x_est,s_vec,b,maxiter=10,tol=1e-4,eps_qp=1e-4);
    # println(io, "First Stage Outer iterations: ", outer_iters1);
    # println(io, "First Stage subproblem iterations: ", num_steps1);
    # println(io, "First Stage CG iterations: ", total_cg_calcs1);
    # (x_est, objs, total_cg_calcs2, num_steps2, outer_iters2) = ProxLinearQuadratic(x_est,s_vec,b,maxiter=5,tol=1e-4,eps_qp=1e-7);
    # loss_thresh=objs[end];
    # println(io, "Second Stage Outer iterations: ", outer_iters2);
    # println(io, "Second Stage subproblem iterations: ", num_steps2);
    # println(io, "Second Stage CG iterations: ", total_cg_calcs2);
    # println(io, "Second stage final loss: ", loss_thresh);
    
    # time_taken = CPUtoc();
    # recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    # println(io,"Second Stage relative recovery error: ", recovery_val_temp);
    # println(io, "#################################################################################")
    # println(io, "Two Stage Completed");
    # println(io, "Two Stage Final loss ", objs[end]);
    # println(io, "Two Stage Loss Gap ", objs[end]-optimized_loss);
    # println(io, "Two Stage relative recovery error: ", recovery_val_temp);
    # println(io, "Two Stage Time consumption ", time_taken);
    # println(io, "Two Stage subproblem iterations ", num_steps1 + num_steps2);
    # println(io, "Two Stage Outer iterations: ", outer_iters1+ outer_iters2);
    # println(io, "Two Stage CG iterations: ", total_cg_calcs1 + total_cg_calcs2);
    # proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    # orth_part=x_est-proj_part;
    # println(io, "Two Stage projection norm: ", norm(proj_part));
    # println(io, "Two Stage orthogonal norm: ", norm(orth_part));
    # println(io, "#################################################################################")
    ########################Step Three: subgradient algorithm################
    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps) = Solving_problem_subgradient(s_vec, b, x_est, loss_tol = loss_thresh, maxiter = 10000);
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "Subgradient Algorithm Completed.");
    println(io, "Subgradient Algorithm Final loss ", objs[end]);
    println(io, "Subgradient Algorithm Loss Gap ", objs[end]-optimized_loss);
    println(io, "Subgradient Algorithm relative recovery error: ", recovery_val_temp);
    println(io, "Subgradient Algorithm Time consumption ", time_taken);
    println(io, "Subgradient Algorithm subproblem iterations ", num_steps)
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "Subgradient Algorithm projection norm: ", norm(proj_part));
    println(io, "Subgradient Algorithm orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")

    # x_est = copy(x_init);
    # CPUtic();
    # (x_est, objs, num_steps) = Solving_problem_subgradient(s_vec, b, x_est, loss_tol = optimized_loss, maxiter = 10000, x_true = x, rel_tol = 1e-7);
    # time_taken = CPUtoc();
    # recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    # println(io, "#################################################################################")
    # println(io, "Subgradient Algorithm Convergence Completed.");
    # println(io, "Subgradient Algorithm Convergence Final loss ", objs[end]);
    # println(io, "Subgradient Algorithm Convergence Loss Gap ", objs[end]-optimized_loss);
    # println(io, "Subgradient Algorithm Convergence relative recovery error: ", recovery_val_temp);
    # println(io, "Subgradient Algorithm Convergence Time consumption ", time_taken);
    # println(io, "Subgradient Algorithm Convergence subproblem iterations ", num_steps)
    # proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    # orth_part=x_est-proj_part;
    # println(io, "Subgradient Algorithm Convergence projection norm: ", norm(proj_part));
    # println(io, "Subgradient Algorithm Convergence orthogonal norm: ", norm(orth_part));
    # println(io, "#################################################################################")

    # #######################Step Four: Low accuracy pogs###############################
    # x_est = copy(x_init);
    # CPUtic();
    # (x_est, objs, total_cg_calcs, num_steps, outer_iters)=ProxLinearQuadratic_low_acc_pogs(x_est, s_vec, b; 
    #             maxiter=max_iter_universe, loss_tol=loss_thresh, rho_coeff=rho_coeff_sel_1);
    # time_taken = CPUtoc();
    # recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    # println(io, "#################################################################################")
    # println(io, "Low accuracy POGS Completed.");
    # println(io, "Low accuracy POGS Final loss ", objs[end]);
    # println(io, "Low accuracy POGS relative recovery error: ", recovery_val_temp);
    # println(io, "Low accuracy POGS Time consumption ", time_taken);
    # println(io, "Low accuracy POGS CG iterations ", total_cg_calcs);
    # println(io, "Low accuracy POGS subproblem iterations ", num_steps);
    # println(io, "Low accuracy POGS Outer iterations: ", outer_iters);
    # proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    # orth_part=x_est-proj_part;
    # println(io, "Low accuracy POGS projection norm: ", norm(proj_part));
    # println(io, "Low accuracy POGS orthogonal norm: ", norm(orth_part));
    # println(io, "#################################################################################")

    # x_est = copy(x_init);
    # CPUtic();
    # (x_est, objs, total_cg_calcs, num_steps, outer_iters)=ProxLinearQuadratic_low_acc_pogs(x_est, s_vec, b; 
    #             maxiter=max_iter_universe, loss_tol=optimized_loss, rho_coeff=rho_coeff_sel_1, x_true = x, rel_tol = 1e-7);
    # time_taken = CPUtoc();
    # recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    # println(io, "#################################################################################")
    # println(io, "Low accuracy POGS Convergence Completed.");
    # println(io, "Low accuracy POGS Convergence Final loss ", objs[end]);
    # println(io, "Low accuracy POGS Convergence relative recovery error: ", recovery_val_temp);
    # println(io, "Low accuracy POGS Convergence Time consumption ", time_taken);
    # println(io, "Low accuracy POGS Convergence CG iterations ", total_cg_calcs);
    # println(io, "Low accuracy POGS Convergence subproblem iterations ", num_steps);
    # println(io, "Low accuracy POGS Convergence Outer iterations: ", outer_iters);
    # proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    # orth_part=x_est-proj_part;
    # println(io, "Low accuracy POGS Convergence projection norm: ", norm(proj_part));
    # println(io, "Low accuracy POGS Convergence orthogonal norm: ", norm(orth_part));
    # println(io, "#################################################################################")

    # #######################Step Five: High accuracy pogs###############################
    # x_est = copy(x_init);
    # CPUtic();
    # (x_est, objs, total_cg_calcs, num_steps, outer_iters)=ProxLinearQuadratic_high_acc_pogs(x_est, s_vec, b; 
    #             maxiter=max_iter_universe, loss_tol=loss_thresh, rho_coeff=rho_coeff_sel_2);
    # time_taken = CPUtoc();
    # recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    # println(io, "#################################################################################")
    # println(io, "High accuracy POGS Completed.");
    # println(io, "High accuracy POGS Final loss ", objs[end]);
    # println(io, "High accuracy POGS relative recovery error: ", recovery_val_temp);
    # println(io, "High accuracy POGS Time consumption ", time_taken);
    # println(io, "High accuracy POGS subproblem iterations ", num_steps);
    # println(io, "High accuracy POGS Outer iterations: ", outer_iters);
    # proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    # orth_part=x_est-proj_part;
    # println(io, "High accuracy POGS projection norm: ", norm(proj_part));
    # println(io, "High accuracy POGS orthogonal norm: ", norm(orth_part));
    # println(io, "#################################################################################")


    # x_est = copy(x_init);
    # CPUtic();
    # (x_est, objs, total_cg_calcs, num_steps, outer_iters)=ProxLinearQuadratic_high_acc_pogs(x_est, s_vec, b; 
    #             maxiter=max_iter_universe, loss_tol=optimized_loss, rho_coeff=rho_coeff_sel_2, rel_tol = 1e-7, x_true = x);
    # time_taken = CPUtoc();
    # recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    # println(io, "#################################################################################")
    # println(io, "High accuracy POGS Convergence Completed.");
    # println(io, "High accuracy POGS Convergence Final loss ", objs[end]);
    # println(io, "High accuracy POGS Convergence relative recovery error: ", recovery_val_temp);
    # println(io, "High accuracy POGS Convergence Time consumption ", time_taken);
    # println(io, "High accuracy POGS Convergence subproblem iterations ", num_steps);
    # println(io, "High accuracy POGS Convergence Outer iterations: ", outer_iters);
    # proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    # orth_part=x_est-proj_part;
    # println(io, "High accuracy POGS Convergence projection norm: ", norm(proj_part));
    # println(io, "High accuracy POGS Convergence orthogonal norm: ", norm(orth_part));
    # println(io, "#################################################################################")

    # #######################Step Six: Low accuracy dual###############################
    # x_est = copy(x_init);
    # CPUtic();
    # (x_est, objs, num_steps, outer_iters)=ProxLinearQuadratic_dual_low_acc(x_est, s_vec, b; 
    #             maxiter=max_iter_universe, loss_tol=loss_thresh, rho_coeff=rho_coeff_sel_1);
    # time_taken = CPUtoc();
    # recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    # println(io, "#################################################################################")
    # println(io, "Low accuracy dual Completed.");
    # println(io, "Low accuracy dual Final loss ", objs[end]);
    # println(io, "Low accuracy dual relative recovery error: ", recovery_val_temp);
    # println(io, "Low accuracy dual Time consumption ", time_taken);
    # println(io, "Low accuracy dual subproblem iterations ", num_steps);
    # println(io, "Low accuracy dual Outer iterations: ", outer_iters);
    # proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    # orth_part=x_est-proj_part;
    # println(io, "Low accuracy dual projection norm: ", norm(proj_part));
    # println(io, "Low accuracy dual orthogonal norm: ", norm(orth_part));
    # println(io, "#################################################################################")
    #######################Step Six: Low accuracy dual convergence###############################
    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps, outer_iters)=ProxLinearQuadratic_dual_low_acc(x_est, s_vec, b; 
                maxiter=max_iter_universe, loss_tol=optimized_loss, rho_coeff=rho_coeff_sel_1, rel_tol = 1e-7, x_true = x);
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "Low accuracy dual Convergence Completed.");
    println(io, "Low accuracy dual Convergence Final loss ", objs[end]);
    println(io, "Low accuracy dual Convergence relative recovery error: ", recovery_val_temp);
    println(io, "Low accuracy dual Convergence Time consumption ", time_taken);
    println(io, "Low accuracy dual Convergence subproblem iterations ", num_steps);
    println(io, "Low accuracy dual Convergence Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "Low accuracy dual Convergence projection norm: ", norm(proj_part));
    println(io, "Low accuracy dual Convergence orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")
    #######################Step Seven: High accuracy dual###############################
    # x_est = copy(x_init);
    # CPUtic();
    # (x_est, objs, num_steps, outer_iters)=ProxLinearQuadratic_dual_high_acc(x_est, s_vec, b; 
    #             maxiter=max_iter_universe, loss_tol=loss_thresh, rho_coeff=rho_coeff_sel_2);
    # time_taken = CPUtoc();
    # recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    # println(io, "#################################################################################")
    # println(io, "High accuracy dual Completed.");
    # println(io, "High accuracy dual Final loss ", objs[end]);
    # println(io, "High accuracy dual relative recovery error: ", recovery_val_temp);
    # println(io, "High accuracy dual Time consumption ", time_taken);
    # println(io, "High accuracy dual subproblem iterations ", num_steps);
    # println(io, "High accuracy dual Outer iterations: ", outer_iters);
    # proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    # orth_part=x_est-proj_part;
    # println(io, "High accuracy dual projection norm: ", norm(proj_part));
    # println(io, "High accuracy dual orthogonal norm: ", norm(orth_part));
    # println(io, "#################################################################################")

    x_est = copy(x_init);
    CPUtic();
    (x_est, objs, num_steps, outer_iters)=ProxLinearQuadratic_dual_high_acc(x_est, s_vec, b; 
                maxiter=max_iter_universe, loss_tol=optimized_loss, rho_coeff=rho_coeff_sel_2, rel_tol = 1e-7, x_true = x);
    time_taken = CPUtoc();
    recovery_val_temp = min(norm(x_est - x) / norm(x), norm(x_est + x) / norm(x));
    println(io, "#################################################################################")
    println(io, "High accuracy dual Convergence Completed.");
    println(io, "High accuracy dual Convergence Final loss ", objs[end]);
    println(io, "High accuracy dual Convergence relative recovery error: ", recovery_val_temp);
    println(io, "High accuracy dual Convergence Time consumption ", time_taken);
    println(io, "High accuracy dual Convergence subproblem iterations ", num_steps);
    println(io, "High accuracy dual Convergence Outer iterations: ", outer_iters);
    proj_part=(sum(x_est .* x)/norm(x)^2)*x;
    orth_part=x_est-proj_part;
    println(io, "High accuracy dual Convergence projection norm: ", norm(proj_part));
    println(io, "High accuracy dual Convergence orthogonal norm: ", norm(orth_part));
    println(io, "#################################################################################")


    println(io, "Everything is completed for current trial.")
    close(io);
end
# arg = parse(Int64, ARGS[1]);
# result=generated_pipeline(arg);
