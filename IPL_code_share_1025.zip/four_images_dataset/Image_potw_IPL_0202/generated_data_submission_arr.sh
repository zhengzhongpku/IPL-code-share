#!/bin/bash

#PBS -l nodes=1:ppn=1
#PBS -l walltime=48:00:00
#PBS -l pmem=12gb
#PBS -A open
#PBS -m n

cd /storage/work/z/zvz5337/Image_potw_IPL_0202/
command_final="julia /storage/work/z/zvz5337/Image_potw_IPL_0202/pipeline2_arr.jl ${command1}"
eval "${command_final}"
