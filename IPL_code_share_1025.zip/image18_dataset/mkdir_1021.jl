for failmulti in ["1"]
    for pfail in ["4"]
        for kk in ["0","1"]
            path="./result/1"*kk*pfail*failmulti*"/"
            if ~isdir(path)
                mkdir(path);
            end
        end
    end
end
