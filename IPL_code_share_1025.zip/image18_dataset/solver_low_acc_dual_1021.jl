#MAX_iter_global is defined in the main file
function ProxLinearQuadratic_dual_low_acc(x_init::Vector{Float64},
    s_vec::Vector{Float64},
    b::Vector{Float64};
    maxiter::Int64=length(s_vec),
    loss_tol::Float64=0.0,
    update_tol::Float64=-1.0,
    rho_coeff::Float64=0.4,
    rel_tol::Float64=0.0,
    x_true = zeros(length(x_init)))

    dd=length(x_init);
    nn=length(s_vec);
    kk=round(Int64,nn/dd);
    x_curr = copy(x_init);
    if (2^Hadamard.intlog(dd) != dd)
        error("Dimension must be power of 2.");
    end
    b_vec = copy(b);
    iter = 0;
    grad_map_norm = Inf;
    objs = zeros(maxiter);
    Wx = zeros(nn);
    grad_map=zeros(dd);
    
    x_delta = zeros(dd);
    d_work_vec = zeros(dd);
    opnorm_A=1;
    lipschitz_const = 2 * opnorm_A^2;
    stepsize=20/(sqrt(median(b))/opnorm_A);
    MultiplyByHS!(x_curr, s_vec, d_work_vec, Wx);
    c_vec =  b_vec .- (Wx).^2;
    D = 2 * Wx;
    subiter_count=0;
    lambda_init=zeros(nn);
    obj = Inf;
    sub_limit_count=0;
    recovery_val_temp = Inf;
    while ((iter < maxiter) && (grad_map_norm > update_tol) && (obj > loss_tol) && (recovery_val_temp > rel_tol))
        (x_delta, subiters, lambda_init) = SolveQP_graph_form_dual_low_acc(dd, s_vec, (1/lipschitz_const)*D , 
                (1/lipschitz_const)*c_vec, t_init=stepsize, rho_coeff=rho_coeff, lambda_init=lambda_init);
        subiter_count += subiters;
        grad_map .= (lipschitz_const/2) .* x_delta;
        x_curr .= x_curr .+ x_delta;
        grad_map_norm=Inf;
        if update_tol>0
            grad_map_norm = norm(grad_map);
        end
        iter = iter + 1;
        MultiplyByHS!(x_curr, s_vec, d_work_vec, Wx);
        D .= 2 .* Wx;
        c_vec .= b_vec .- Wx.^2;
        obj = norm(c_vec, 1);
        objs[iter] = obj;
        recovery_val_temp = min(norm(x_curr - x_true) / norm(x_true), norm(x_curr + x_true) / norm(x_true));
        if subiters >= MAX_iter_global-1
            sub_limit_count=sub_limit_count+1;
        end
        if sub_limit_count>=maxiter_sub_limit1
            break;
        end
    end
    objs = objs[1:iter];
    return (x_curr, objs, subiter_count, iter);
end


function SolveQP_graph_form_dual_low_acc(dd::Int64, s_vec::Vector{Float64},
    D::Vector{Float64}, c_vec::Vector{Float64};
    rho_coeff::Float64=0.5,
    MAXITER::Int64=MAX_iter_global,
    t_init::Float64 = 1.0,
    lambda_init::Vector{Float64} = zeros(size(c_vec)[1]))

    s_vec_neg=-s_vec;
    nn = length(s_vec);
    kk = round(Int64, nn / dd);
    t=t_init;
    loss_init=norm(c_vec, 1);
    iter = 0;
    lambda_x=zeros(nn);
    lambda_y=zeros(nn);
    lambda_x_record=zeros(nn);
    lambda_y_record=zeros(nn);
    lambda_z=zeros(nn);

    lambda_x .= lambda_init;
    lambda_y .= lambda_init;
    lambda_x_record .= lambda_init;
    lambda_y_record .= lambda_init;
    lambda_z .= lambda_init;
    x=zeros(dd);
    y=zeros(nn);
    c_minus_y=zeros(nn);
    temp1 = zeros(nn);
    temp2 = zeros(dd);
    gamma=1.0;
    loss_primal_part1=0.0;
    loss_primal_part2=0.0;
    loss_primal=loss_primal_part1+loss_primal_part2;
    loss_decrease=0.0;
    loss_gap=Inf;
    n_work_vec = zeros(nn);
    d_work_vec = zeros(dd);
    while (iter < MAXITER) && (loss_gap > rho_coeff*loss_decrease)
        lambda_z .= (1-gamma) .* lambda_x .+ gamma .* lambda_y;
        #mul!(x, AT, lambda_z, -1, false)
        MultiplyByDHST!(lambda_z, s_vec_neg, D, n_work_vec, x);
        #mul!(y,A,x);
        MultiplyByDHS!(x, s_vec, D, d_work_vec, y);
        c_minus_y .= c_vec .- y;
        for counting in 0:100
          shrink=0.5^counting;
          lambda_y .= lambda_y_record .- (shrink*t/gamma) .* c_minus_y;
          lambda_y[lambda_y .> 1.0] .= 1.0;
          lambda_y[lambda_y .< -1.0] .= -1.0;
          lambda_x .= (1-gamma) .* lambda_x_record .+ gamma .* lambda_y;
          temp1 .= lambda_x .- lambda_z;
          #mul!(temp2, AT, temp1);
          MultiplyByDHST!(temp1, s_vec, D, n_work_vec, temp2);
          if (norm(temp2)^2 <= 1/shrink/t*norm(temp1)^2)
            lambda_x_record .= lambda_x;
            lambda_y_record .= lambda_y;
            t=t*shrink;
            break;
          end
        end
        gamma=2/(1+sqrt(1+4/(gamma^2)))
        loss_primal_part1=0.5*norm(x)^2;
        loss_primal_part2=norm(c_minus_y,1);
        loss_primal=loss_primal_part1+loss_primal_part2;
        loss_decrease=loss_init-loss_primal;
        loss_gap=2*loss_primal_part1+loss_primal_part2+dot(lambda_z,c_vec);
        iter += 1;
    end
    return (x, iter, lambda_y);
end
